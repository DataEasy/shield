package br.com.dataeasy.agentclient;

public class DocflowConfig {
}
